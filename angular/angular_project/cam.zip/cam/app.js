var express = require('express');
const app = express();

path = require('path');
app.use("/public", express.static(path.join(__dirname, '/public')));

var url = require('url');

const fileUpload = require('express-fileupload');
app.use(fileUpload({
    useTempFiles : true,
    tempFileDir : '/tmp/'
}));

var mongoose = require('mongoose');
var db = "mongodb://localhost/camera";
mongoose.connect(db,function(err){
    console.log(err);
});

var cam = require("./model/cam.js");

app.set("view engine", "ejs");

var bodyparser = require('body-parser');
app.use(bodyparser.urlencoded({extended:true}))


app.get("/",function(req,res){
    cam.find({},function(err,tbdata){

        if(err){
            res.send(err);
        }else{
            res.render('index', {data:tbdata});
        }
    })
})

app.get('/camadd', function(req, res, next) {
    res.render('camadd');
});
  
app.post("/insert",function(req,res, next){
    var id = req.body.id;
    var name = req.body.name;
    var model_type = req.body.model_type;
  
    var color = req.body.color;
    var company = req.body.company;
    var cam_type = req.body.cam_type;
  
    var resolution = req.body.resolution;
    var video_resolution = req.body.video_resolution;
    var auto_focus = req.body.auto_focus;
  
    var connectivity = req.body.connectivity;
    var other = req.body.other;
    var price = req.body.price;
  
    let sampleFile = req.files.pic;
  
    var cam1 = new cam();
    cam1.id = id;
    cam1.name = name;
    cam1.model_type = model_type;
  
    cam1.color = color;
    cam1.company = company;
    cam1.cam_type = cam_type;
  
    cam1.resolution = resolution;
    cam1.video_resolution = video_resolution;
    cam1.auto_focus = auto_focus;
  
    cam1.connectivity = connectivity;
    cam1.other = other;
    cam1.price = price;
    cam1.pic = sampleFile.name;
  
    cam1.save(function(err,result){
        if(err){
            console.log(err);
        }else{
            console.log("Data Inserted!!");
            res.redirect('/');
        }
    });
    //res.writeHead(200, {"Content-Type": "text/plain"});
    sampleFile.mv(__dirname + "/public/images/"+sampleFile.name,function(err){
        if(err){
            res.send(err);
        }
    });
  })

app.get("/delete",function(req,res){
    var url_parts = url.parse(req.url, true);
    var query = url_parts.query;
    var id = req.query.id;

    cam.deleteOne({id:id},function(err){
        if(err){
            console.log(err);
        }else{
            console.log("Data Deleted!!");
            res.redirect('/');
        }
    })
})

app.get("/camedit",function(req,res){
    var url_parts = url.parse(req.url, true);
    var query = url_parts.query;
    var id = req.query.id;

    cam.find({id:id},function(err,tbdata){
        if(err){
            res.send(err);
        }else{
            res.render('camedit', {data:tbdata});
        }
    })
})
  
app.post("/update",function(req,res){
    var id = req.body.id;
    var name = req.body.name;
    var model_type = req.body.model_type;
  
    var color = req.body.color;
    var company = req.body.company;
    var cam_type = req.body.cam_type;
  
    var resolution = req.body.resolution;
    var video_resolution = req.body.video_resolution;
    var auto_focus = req.body.auto_focus;
  
    var connectivity = req.body.connectivity;
    var other = req.body.other;
    var price = req.body.price;

    let sampleFile = req.files.pic;
    if(sampleFile != null){
        sampleFile.mv(__dirname + "/public/images/"+sampleFile.name,function(err){
            if(err){
                res.send("Error Occurred!!Plz try again!!");
            }else{
            }
        });
    }

    cam.findOne({id:id},function(err,tbdata){
        tbdata.id = id;
        tbdata.name = name;
        tbdata.model_type = model_type;
      
        tbdata.color = color;
        tbdata.company = company;
        tbdata.cam_type = cam_type;
      
        tbdata.resolution = resolution;
        tbdata.video_resolution = video_resolution;
        tbdata.auto_focus = auto_focus;
      
        tbdata.connectivity = connectivity;
        tbdata.other = other;
        tbdata.price = price;
        if(sampleFile){
            tbdata.pic = sampleFile.name;
        }
        tbdata.save();
        if(err){
            res.send(err);
        }else{
            res.redirect('/');
        }
    })

    
})

app.listen(process.env.PORT || 5000,function(req,res){
    console.log("Server Ready");
})